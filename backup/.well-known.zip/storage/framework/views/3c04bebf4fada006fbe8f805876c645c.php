<footer class="footer-wrapper">
        <div class="container">

            <div class="row justify-content-center">



                <div class="col-lg-4 wow fadeInLeft" data-wow-duration="2s">
                    <div class="footer">
                        <h3 class="foot-head mb-3">KETTIMELAM MATRIMONY</h3>

                        <p> Welcome to Kettimelam Matrimony where we make heavenly matches a reality. Our mission is to guide you to your perfect partner with expert assistance and a user-friendly website. </p>

                        <p>Join us and let's make your dreams come true! Marriages are destined in heaven, and at kettimelammatrimony.com, we bring these destinies together. </p>

                        <p>In the modern world, finding the right life partner requires the latest technology and expert guidance. Our platform is designed to stand out, offering services and assistance to brides, grooms, and parents.</p>

                    </div>

                </div>

                <div class="col-lg-2 wow fadeInLeft" data-wow-duration="2s">
                    <div class="footer" style="border-left:2px solid #C8C8C8; padding-left:10px;">
                        <h3 class="foot-head mb-3">LINKS</h3>
                        <ul>
                            <li><i class="fas fa-heart"></i><a href="about-us"> About Us</a></li>
                            <li><i class="fas fa-heart"></i><a href="contact"> Contact Us</a></li>
                            <li><i class="fas fa-heart"></i><a href="faq"> Faq</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-2 wow fadeInRight" data-wow-duration="2s">
                    <div class="footer" style="border-left:2px solid #C8C8C8; padding-left:10px;">
                        <h3 class="foot-head mb-3">QUICK LINKS</h3>
                        <ul>
                            <li><i class="fas fa-heart"></i><a href="safety-tips"> Safety Tips</a></li>
                            <li><i class="fas fa-heart"></i><a href="privacypolicy">Privacy Policy</a></li>
                            <li><i class="fas fa-heart"></i><a href="terms"> Terms and Conditions</a></li>
                        </ul>
                    </div>
                </div>

                <div class="col-lg-4 wow fadeInRight" data-wow-duration="2s">
                    <div class="footer">
                        <h5>All Credit & Debit cards are Accepted!</h5>
                        <img src="images/payment_type.webp" class="img-fluid">
                    </div>
                    <div class="footer-social mt-10">                                    
                        <a href="#" contenteditable="false" style="cursor: pointer;"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" contenteditable="false" style="cursor: pointer;"><i class="fab fa-instagram"></i></a>
                        <a href="#" contenteditable="false" style="cursor: pointer;"><i class="fab fa-twitter"></i></a>
                    </div>
                    <div class="footer  mt-3 mb-2">
                        <a href="#" class="btn-web-green-big1"  data-bs-toggle="modal" data-bs-target="#register1">Register Now</a>
                    </div>
                </div>


                <div class="col-lg-12 wow fadeInUp" data-wow-duration="2s">
                    <div class="footer mt-5 text-center">
                        <p class="text-right">Our website is for finding lifelong partners, not a dating website. Copyright ©2024. All rights reserved | Kettimelam Matrimony</p>
                    </div>
                </div>

            </div>
        </div>
    </footer><?php /**PATH /home2/kettimelammatrim/kettimelammatrimony.com/resources/views/include/footer.blade.php ENDPATH**/ ?>