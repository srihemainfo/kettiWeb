 <style>

 </style>
 @include('include.header')
 <section id="clinox-breadcrumb" class="clinox-breadcrumb-section position-relative top-position"
     style="background-image: linear-gradient(rgba( 0,0,0,.5), rgba(0,0,0,.5)),url(images/breadcrumb-bg.webp);background-position: bottom;background-size: cover;">
     <div class="container">
         <div class="breadcrumb-content headline ul-li position-relative text-center">
             <div class="d-flex justify-content-center align-items-start">
                 <img src="images/marriage-ring.webp" alt="marriage-ring" style="width: 3rem; margin-right: 1rem;">
                 <h2>Safety-Tips</h2>
             </div>
             <ul>
                 <li><a href="home" contenteditable="false" style="cursor: pointer; color: #fff;">Home</a></li>
                 <li>Safety-Tips</li>
             </ul>
         </div>
     </div>
 </section>
 <section class="privacy-sec mt-5 mb-5 p-3">
     <div class="container">
         <div class="row">
             <div class="col-md-12">
                 <div id="content">

                     <div class="row justify-content-center" style="margin-bottom: 2rem;">

                         <div class="col-lg-6">
                             <div class="web-title wow fadeInUp animated" data-wow-duration="2s"
                                 style="visibility: visible;-webkit-animation-duration: 2s; -moz-animation-duration: 2s; animation-duration: 2s;">

                                 <h3 class="mb-3" style="font-size: 40px;">Safety Tips</h3>


                             </div>
                             <div class="st-seperator">
                                 <div class="st-seperator-left wow fadeInLeft animated" data-wow-duration="1s"
                                     data-wow-delay="0.2s"
                                     style="visibility: visible;-webkit-animation-duration: 1s; -moz-animation-duration: 1s; animation-duration: 1s;-webkit-animation-delay: 0.2s; -moz-animation-delay: 0.2s; animation-delay: 0.2s;">
                                 </div>
                                 <div class="st-seperator-center"><img src="images/4.webp" alt="icon"></div>
                                 <div class="st-seperator-right wow fadeInRight animated" data-wow-duration="1s"
                                     data-wow-delay="0.2s"
                                     style="visibility: visible;-webkit-animation-duration: 1s; -moz-animation-duration: 1s; animation-duration: 1s;-webkit-animation-delay: 0.2s; -moz-animation-delay: 0.2s; animation-delay: 0.2s;">
                                 </div>
                             </div>
                         </div>


                     </div>

                     <p>Kettimelammatrimony.com is a matrimonial portal providing multi-faceted platforms, endeavouring
                         constantly to provide you with the best matrimonial services. Since we are strongly committed
                         to your right to privacy, we have drawn out a privacy statement with regard to the information
                         we collect from you. We use a safe server for credit card transactions to protect the credit
                         card information of our clients and Cookies are used to store the login information.</p>
                     <p><strong style="color: #008000;">1. In <a href="http://www.kettimelammatrimony.com/"
                                 contenteditable="false" style="cursor: pointer;">www.kettimelammatrimony.com</a>,
                             colour photo of the alliance must be attached, why?</strong></p>
                     <p>Yes, there is one customery word that “One photo will express lot of words”. Bio-data of the
                         alliance will be good and live only if the photo is attached in it, Why because, lot of
                         alliance seekers use to give first preference for the alliance details with photo. So, you
                         please attach the colour photo with smiling face.</p>

                     <p><strong style="color: #008000;">2. Where you have to arrange for meetings?</strong></p>
                     <p>Till you ascertain the full and clear details of the alliance, you need not meet the person in
                         private. After getting clear details of the alliance, you can meet in Coffee Shop, Shopping
                         Mall, Worship places or any other common places. Please avoid to meet the alliance in Hotel
                         room & private places.</p>

                     <p><strong style="color: #008000;">3. Why you shall not give more details unnecessarily?</strong>
                     </p>
                     <p>It will be good if you take diligent care &amp; very cautious at the time of meeting the
                         interested alliance or contacting over cell phone.&nbsp; Please take more time to collect the
                         particulars/details about the alliance.&nbsp;&nbsp; Don’t disclose your personal and family
                         details unnecessarily.&nbsp;</p>
                     <p><strong style="color: #008000;">4. How to safeguard ourselves from cheating/cash
                             scandal?</strong></p>
                     <p>Please don't tell to the details about your Credit / Debit card and bank balance to the selected
                         alliance and his/her relatives. Before getting the fixation of the marriage don’t help the
                         alliance and his/her relatives by way of cash and any mode.</p>

                     <p><strong style="color: #008000;">5. At the time of meeting the selected alliance, introduce or
                             make participation of relatives, why?</strong></p>
                     <p>Marriages are not get together of the two persons; It’s an get together of two families.
                         Therefore, the suggestions from both side families will be useful for us at the time of their
                         discussions.</p>

                     <p><strong style="color: #008000;">6. You are sole responsible for your future, why?</strong></p>
                     <p>Marriage is an important and one time decision you are going to take in your life time. So, it
                         is clear that nobody else, except you, will decide in best way. Therefore, before come to a
                         conclusion, better you have to discuss more times with people who cares you very much and do
                         deep enquiry.</p>

                     <p><strong style="color: #008000;">7. Marriage is very much delayed! What are all points to be
                             considered for immediate marriage?</strong></p>
                     <p>You do searching more alliances according to your expectations. If you not searching in lot,
                         then you can reduce your expectations for quicker marriage/alliance settlement.</p>

                     <p><strong style="color: #008000;">8. Due to Horoscope marriage is getting delayed; what has to be
                             done?</strong></p>
                     <p>In Tamil there is one proverb, If you always look at the squares of the of the Horoscopes,
                         marriage is not possible; likewise, Always if you find faults/mistakes; you can not lead your
                         family.</p>
                     <p>If the marriage is continuously postponed/not coming into alliance settlement quickly; you have
                         to discuss with more astrologers instead of one astrologer.</p>
                     <p>Lot of marriages are successful even with the name matches alone done. Whereas lot of marriages
                         are broken even after 10 matching points are verified. Therefore to take correct and good
                         decision to fix up the marriage, please discuss your friends and relatives. Best wishes for an
                         early marriage.</p>

                     <p><strong style="color: #008000;">9. What steps to be taken before going to search
                             alliance?</strong></p>
                     <p>With clear consultation & acceptance from the elders of your family, clear verifications with
                         respect to photo, bio-data, horoscope and the alliance matching with our requirements, get
                         appointment/time over phone and visit the alliance place.</p>

                     <p><strong style="color: #008000;">10. What are all to be done and not to be done at the time of
                             going to see the Bride?</strong></p>
                     <p>At the time of going to see the ‘Bride’, you accompany with the married women relatives who are
                         all very close to Bridegroom. At any cause, you should not go along with Bridegroom’s unmarried
                         friends.</p>

                     <p><strong style="color: #008000;">11. Which is important for marriage?</strong></p>
                     <p>There must be clear intention, wish in between Bride & Bridegroom apart from the parents and
                         relatives wish & acceptance.</p>

                     <p style="text-align: center;"><strong style="color: #008000;">Kettimelammatrimony.com is an
                             organisation </strong></p>
                     <p style="text-align: center;"><strong style="color: #008000;">only to do “Introduction of
                             alliance”</strong></p>
                     <p>Lot of money, hardwork, sacrifice to develop your son/daughter and for their studies you have
                         spent so far. To get better alliance for them, you please carefully enquire the relatives &
                         friends of that particular alliance before come to a conclusion. Don’t be Hurry!. This may need
                         some hundreds and number of days only.</p>

                 </div>
             </div>
         </div>
     </div>
 </section>

 @include('include.footer')
